const welcomeTexts = ["At the start of the game, you will have the opportunity to select one or more musical themes from a variety of options. Choose the themes that interest you the most, whether it's \"Classic Rock\", \"Contemporary Pop Music\", \"90s Hip-Hop\", or any other theme that appeals to you.",

"Every time you answer a question correctly, you earn 5 points. Quiz questions will typically involve reading the lyrics of a song and identifying the corresponding song or artist.",

"From time to time you will have the chance to answer bonus questions. If you answer a bonus question correctly, you will get an extra point. These questions may be a little more difficult, so pay attention!",

"You are allowed to make up to 5 mistakes throughout the game. If you answer a question incorrectly, it counts as an error. When you reach 5 errors, it's the end of the quiz.",

"If a song is too difficult and you cannot recognize it, you have the option to move on to the next question. However, each move to the next music will cost you a mistake. You have a total of 5 errors allowed throughout the quiz. Moving on to the next question will therefore bring you closer to the 5 error threshold more quickly.",

"After each game, your score will be displayed, and you will be able to see how you stack up against other players. Aim for the highest score possible and challenge your friends to see who is the music champion!",

"We hope these rules help you have fun while testing your musical knowledge."]



let GameSession = {
    name: "",
    questionN: 0,
    themes: [true, true, true, true, true],
    starting: false,
    started: false
}

let currentBlock = 0;
let blocks = [
    "welcome-message",
    "username-message",
    "theme-message"
];

let currentMessage = 0;

function updateMessage() {

    const e = document.getElementById("welcome-message-text");
    e.innerHTML = welcomeTexts[currentMessage];

    if (currentMessage == welcomeTexts.length - 2) {
        const nextButton = document.getElementById("welcome-message-skip");
        nextButton.disabled = true;
    }

}

function nextMessage() {
    currentMessage++;
    updateMessage();
}
function closeMessage(){
    currentBlock++;
    updateBlock();
}

function updateBlock() {
    for(const b of blocks) {
        document.getElementById(b).classList.remove("visible");
    }
    if (currentBlock<blocks.length) document.getElementById(blocks[currentBlock]).classList.add("visible");
    else document.getElementById("top-layer").classList.add("done");
}

function saveUsername() {
    let username = document.getElementById("username-input").value;
    if (!username) {
        return alert("Veuillez entrer un nom correct.");
    }
    GameSession.name = username;
    currentBlock++;
    updateBlock();
}

function saveTheme() {

    currentBlock++;
    updateBlock();
    startCounter();
}

let counter = 3;
function startCounter() {
    GameSession.starting = true;
    updateCounter();
    setTimeout(updateCounter, 1000);
    setTimeout(updateCounter, 2000);
    setTimeout(updateCounter, 3000);
    setTimeout(startGame, 4000);
}

function updateCounter() {
    document.getElementById("game-counter").innerHTML = counter >= 1 ? counter-- : "Let's go";
}

function startGame() {
    GameSession.started = true;
    GameSession.round = 0;
    document.getElementById("game-counter").style.display = "none";
    startRound();
}

function startRound() {

}


window.onload = () => {
    updateMessage();
    updateBlock();
}

function toggleTheme(n) {

    if (GameSession.themes[n]) {
        document.getElementById("theme"+n).classList.remove("selected");
        GameSession.themes[n] = false;
        return;
    }
    document.getElementById("theme"+n).classList.add("selected");
    GameSession.themes[n] = true;
    
}